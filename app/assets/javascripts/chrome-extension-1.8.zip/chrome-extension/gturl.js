var cururl = window.location.host;
